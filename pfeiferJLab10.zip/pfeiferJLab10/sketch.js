let circleX = 0;
let targetFPS = 30;

function setup(){
	createCanvas(400, 400);
	myFPS = createFPS();
	myFPS.element.style('color', 'blue');
}
function draw(){
	frameRate(targetFPS);
	background(220);
	updateFPS(myFPS);
	noStroke();
	fill('red');
	circle(circleX, 200, 30);
	circleX+=2;
	if(circleX>410){
		circleX=0;
	}
	if(circleX==300){
		console.log(targetFPS);
	}
}
function keyPressed(){
	if(key==='a'&&targetFPS>=10){
		targetFPS-=5;
	}
	if(key==='d'&&targetFPS<=60){
		targetFPS+=5;
	}
}