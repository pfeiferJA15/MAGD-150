let fruits = ["banana", "apple", "tomato", "strawberry", "watermelon", "grape", "raspberry", "lemon", "dragonfruit", "kiwi"]
let fruitsEaten = [];
let fruitsComposite = [];

function setup() {
  createCanvas(600, 600);
  background(220);
  for(let i = 0; i < 5; i++)
  {
    let num = Math.floor(random(0, fruits.length));
    console.log(num);
    fruitsEaten.push(fruits[num]);
    fruits.splice(num, 1);
    
  }
  for(let j = 0; j < 10; j++)
  {
    if(j < 5)
    {
      fruitsComposite.push(fruits[j]);
    }
    if(j >= 5)
    {
      fruitsComposite.push(fruitsEaten[j-5]);
    }
  }
  console.log(fruitsComposite);
  text("The uneaten fruits are " + fruits, 30, 150);
  text("The eaten fruits are " + fruitsEaten, 30, 170);
  text("A random uneaten fruit is " + fruits[Math.floor(random(0, fruits.length))], 30, 190);
  text("A random eaten fruit is " + fruitsEaten[Math.floor(random(0, fruits.length))], 30, 210);
  text("A random fruit (eaten or uneaten) is " + fruitsComposite[Math.floor(random(0, fruitsComposite.length))], 30, 230);
}

