let uwwImage;
let treeImage;

function preload() {
  uwwImage = loadImage('assets/about-uww-main.jpg');
  // about-uww-main.jpg from https://www.uww.edu/about-uw-whitewater
  treeImage = loadImage('assets/christmastree.png');
  // christmastree.png from https://www.pngkey.com/maxpic/u2w7q8w7q8y3t4i1/
}


function setup() {
  createCanvas(600, 400);
  
}

function draw() {
  background(220);
  scale(0.44);
  image(uwwImage, -400, 0);
  scale(1.25);
  image(treeImage, mouseX*1.5, mouseY);
  textFont('Helvetica');
  textSize(50);
  fill('green');
  stroke('red');
  strokeWeight(5);
  scale(1);
  text('Merry Christmas from UW Whitewater!', 150, 100);
}